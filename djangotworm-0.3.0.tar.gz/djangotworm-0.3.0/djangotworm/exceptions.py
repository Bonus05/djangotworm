class FetchNotCalled(Exception):
    pass